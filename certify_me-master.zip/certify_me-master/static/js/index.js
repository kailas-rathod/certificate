$(document).ready(function() {
  //index frame
  //ajax for login, load client partial or email partial, depending on user permissions

});
